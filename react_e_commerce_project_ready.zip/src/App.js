import React, { useMemo, useState } from "react";
import { ShoppingCart, Search, Filter, X, Star, Trash2, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";

// ----- Mock Data -----
const RAW_PRODUCTS = [
  { id: 1, title: "Classic White Tee", price: 890, rating: 4.5, category: "Fashion", img: "https://picsum.photos/id/100/600/600", stock: 32, tags: ["cotton", "unisex"], },
  { id: 2, title: "Minimalist Backpack", price: 2490, rating: 4.7, category: "Bags", img: "https://picsum.photos/id/101/600/600", stock: 15, tags: ["travel", "waterproof"], },
  { id: 3, title: "Wireless Earbuds", price: 3290, rating: 4.2, category: "Electronics", img: "https://picsum.photos/id/102/600/600", stock: 18, tags: ["bluetooth", "noise-cancel"], },
  { id: 4, title: "Sports Sneakers", price: 4590, rating: 4.6, category: "Fashion", img: "https://picsum.photos/id/103/600/600", stock: 22, tags: ["running", "breathable"], },
  { id: 5, title: "Ceramic Mug", price: 390, rating: 4.1, category: "Home", img: "https://picsum.photos/id/104/600/600", stock: 44, tags: ["kitchen", "dishwasher-safe"], },
  { id: 6, title: "Smartwatch", price: 5290, rating: 4.4, category: "Electronics", img: "https://picsum.photos/id/105/600/600", stock: 9, tags: ["fitness", "waterproof"], },
  { id: 7, title: "Desk Lamp", price: 1250, rating: 4.0, category: "Home", img: "https://picsum.photos/id/106/600/600", stock: 27, tags: ["LED", "dimmable"], },
  { id: 8, title: "Leather Wallet", price: 1490, rating: 4.3, category: "Fashion", img: "https://picsum.photos/id/107/600/600", stock: 30, tags: ["genuine", "gift"], },
  { id: 9, title: "Yoga Mat", price: 990, rating: 4.5, category: "Sports", img: "https://picsum.photos/id/108/600/600", stock: 20, tags: ["non-slip", "lightweight"], },
  { id: 10, title: "Scented Candle", price: 590, rating: 4.2, category: "Home", img: "https://picsum.photos/id/109/600/600", stock: 36, tags: ["lavender", "gift"], },
];

const CATEGORIES = ["All", "Fashion", "Bags", "Electronics", "Home", "Sports"];

// ----- Helpers -----
const BDT = (n) => new Intl.NumberFormat("bn-BD", { style: "currency", currency: "BDT", maximumFractionDigits: 0 }).format(n);

function Rating({ value }) {
  const stars = Array.from({ length: 5 }).map((_, i) => (
    <Star key={i} className={`h-4 w-4 ${i < Math.round(value) ? "fill-current" : ""}`} />
  ));
  return <div className="flex items-center gap-1 text-yellow-500">{stars}</div>;
}

function ProductCard({ product, onClick, onFav }) {
  return (
    <Card className="rounded-2xl overflow-hidden hover:shadow-xl transition-shadow">
      <div className="relative">
        <img src={product.img} alt={product.title} className="aspect-square w-full object-cover" />
        <Button size="icon" variant="secondary" className="absolute top-3 right-3 rounded-full" onClick={(e)=>{e.stopPropagation(); onFav?.(product);}}>
          <Heart className="h-4 w-4" />
        </Button>
      </div>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h3 className="font-semibold text-lg leading-snug line-clamp-2">{product.title}</h3>
            <div className="mt-1 flex items-center gap-2">
              <Rating value={product.rating} />
              <Badge variant="secondary">{product.category}</Badge>
            </div>
          </div>
          <div className="text-right whitespace-nowrap font-bold">{BDT(product.price)}</div>
        </div>
        <Button className="mt-4 w-full" onClick={() => onClick(product)}>View & Add</Button>
      </CardContent>
    </Card>
  );
}

export default function EcommerceDemo() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const [sort, setSort] = useState("popular");
  const [price, setPrice] = useState([0, 6000]);
  const [openCart, setOpenCart] = useState(false);
  const [selected, setSelected] = useState(null);
  const [cart, setCart] = useState({}); // {id: {product, qty}}
  const [favs, setFavs] = useState(new Set());

  const products = useMemo(() => {
    let list = RAW_PRODUCTS.filter(p =>
      (cat === "All" || p.category === cat) &&
      p.price >= price[0] && p.price <= price[1] &&
      p.title.toLowerCase().includes(q.toLowerCase())
    );
    if (sort === "price-asc") list.sort((a,b)=>a.price-b.price);
    if (sort === "price-desc") list.sort((a,b)=>b.price-a.price);
    if (sort === "rating") list.sort((a,b)=>b.rating-a.rating);
    return list;
  }, [q, cat, sort, price]);

  const subtotal = Object.values(cart).reduce((s, item) => s + item.product.price * item.qty, 0);

  const addToCart = (product, qty = 1) => {
    setCart(prev => {
      const current = prev[product.id]?.qty || 0;
      const nextQty = Math.min(current + qty, product.stock);
      return { ...prev, [product.id]: { product, qty: nextQty } };
    });
  };
  const removeFromCart = (id) => setCart(prev => { const cp = {...prev}; delete cp[id]; return cp; });
  const setQty = (id, qty) => setCart(prev => ({ ...prev, [id]: { ...prev[id], qty: Math.max(1, Math.min(qty, prev[id].product.stock)) } }));

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-3">
          <div className="font-extrabold text-2xl tracking-tight">Shop<span className="text-primary">Bangla</span></div>
          <div className="ml-auto flex items-center gap-2 w-full max-w-xl">
            <div className="relative flex-1">
              <Input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="সার্চ করুন…" className="pl-10 rounded-2xl" />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 opacity-60" />
            </div>
            <Select value={sort} onValueChange={setSort}>
              <SelectTrigger className="w-40 rounded-2xl"><SelectValue placeholder="Sort" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="popular">Popular</SelectItem>
                <SelectItem value="rating">Top Rated</SelectItem>
                <SelectItem value="price-asc">Price: Low → High</SelectItem>
                <SelectItem value="price-desc">Price: High → Low</SelectItem>
              </SelectContent>
            </Select>
            <Sheet open={openCart} onOpenChange={setOpenCart}>
              <SheetTrigger asChild>
                <Button variant="default" className="rounded-2xl">
                  <ShoppingCart className="h-4 w-4 mr-2" /> কার্ট ({Object.keys(cart).length})
                </Button>
              </SheetTrigger>
              <SheetContent className="w-[420px] sm:w-[480px]">
                <SheetHeader>
                  <SheetTitle>আপনার কার্ট</SheetTitle>
                </SheetHeader>
                <div className="mt-4 space-y-4">
                  {Object.values(cart).length === 0 && (
                    <p className="text-sm text-muted-foreground">কার্ট খালি। পণ্য যোগ করুন।</p>
                  )}
                  {Object.values(cart).map(({ product, qty }) => (
                    <div key={product.id} className="flex items-center gap-3 border rounded-xl p-2">
                      <img src={product.img} className="h-16 w-16 rounded-lg object-cover" />
                      <div className="flex-1">
                        <div className="font-medium leading-tight">{product.title}</div>
                        <div className="text-xs text-muted-foreground">{BDT(product.price)} × {qty}</div>
                        <div className="mt-2 flex items-center gap-2">
                          <Button size="sm" variant="outline" className="rounded-full px-3" onClick={()=> setQty(product.id, Math.max(1, qty-1))}>-</Button>
                          <span className="w-8 text-center">{qty}</span>
                          <Button size="sm" variant="outline" className="rounded-full px-3" onClick={()=> setQty(product.id, qty+1)}>+</Button>
                        </div>
                      </div>
                      <Button size="icon" variant="ghost" onClick={()=> removeFromCart(product.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
                <div className="mt-6 border-t pt-4 flex items-center justify-between">
                  <div className="text-sm">সাবটোটাল</div>
                  <div className="font-bold text-lg">{BDT(subtotal)}</div>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="mt-4 w-full rounded-2xl" disabled={subtotal===0}>চেকআউট করুন</Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-lg rounded-2xl">
                    <DialogHeader>
                      <DialogTitle>ডেলিভারি তথ্য</DialogTitle>
                    </DialogHeader>
                    <form
                      className="space-y-3"
                      onSubmit={(e)=>{e.preventDefault(); alert("Order placed! This is a demo.");}}
                    >
                      <Input placeholder="পূর্ণ নাম" required className="rounded-xl" />
                      <Input placeholder="ফোন নম্বর" type="tel" required className="rounded-xl" />
                      <Input placeholder="ঠিকানা" required className="rounded-xl" />
                      <Select defaultValue="cod">
                        <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cod">ক্যাশ অন ডেলিভারি</SelectItem>
                          <SelectItem value="card">কার্ড পেমেন্ট (ডেমো)</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button type="submit" className="w-full rounded-xl">অর্ডার কনফার্ম</Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      {/* Body */}
      <main className="max-w-7xl mx-auto px-4 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Filters */}
        <aside className="lg:col-span-3">
          <Card className="rounded-2xl sticky top-20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Filter className="h-4 w-4" /> ফিল্টার</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <div className="text-sm mb-2 font-medium">ক্যাটাগরি</div>
                <div className="flex flex-wrap gap-2">
                  {CATEGORIES.map((c) => (
                    <Button key={c} size="sm" variant={cat===c?"default":"outline"} className="rounded-full" onClick={()=> setCat(c)}>{c}</Button>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-sm mb-2 font-medium">দাম (BDT)</div>
                <Slider value={price} max={6000} step={50} onValueChange={setPrice} className="py-4" />
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>{BDT(price[0])}</span>
                  <span>{BDT(price[1])}</span>
                </div>
              </div>
              <Button variant="ghost" className="rounded-xl" onClick={()=>{setQ(""); setCat("All"); setSort("popular"); setPrice([0,6000]);}}>রিসেট</Button>
            </CardContent>
          </Card>
        </aside>

        {/* Products */}
        <section className="lg:col-span-9">
          {products.length === 0 ? (
            <div className="p-10 border rounded-2xl text-center text-muted-foreground">কোনো পণ্য পাওয়া যায়নি</div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
              {products.map((p) => (
                <Dialog key={p.id} open={selected?.id===p.id} onOpenChange={(o)=> !o && setSelected(null)}>
                  <DialogTrigger asChild>
                    <div>
                      <ProductCard product={p} onClick={setSelected} onFav={(prod)=> setFavs(prev=> new Set(prev).add(prod.id))} />
                    </div>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-2xl rounded-2xl">
                    <DialogHeader>
                      <DialogTitle>{p.title}</DialogTitle>
                    </DialogHeader>
                    <div className="grid sm:grid-cols-2 gap-6">
                      <img src={p.img} className="w-full rounded-xl object-cover" />
                      <div>
                        <div className="flex items-center gap-3">
                          <Rating value={p.rating} />
                          <Badge variant="secondary">{p.category}</Badge>
                          <span className="text-sm text-muted-foreground">স্টক: {p.stock}</span>
                        </div>
                        <div className="mt-3 text-2xl font-bold">{BDT(p.price)}</div>
                        <div className="mt-4 flex items-center gap-2">
                          {p.tags.map(t => <Badge key={t} variant="outline" className="rounded-full">#{t}</Badge>)}
                        </div>
                        <div className="mt-6 flex items-center gap-2">
                          <Button className="rounded-2xl" onClick={()=> { addToCart(p, 1); setOpenCart(true); }}>কার্টে যোগ করুন</Button>
                          <Button variant="outline" className="rounded-2xl" onClick={()=> setFavs(prev=> new Set(prev).add(p.id))}>পছন্দের তালিকা</Button>
                        </div>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              ))}
            </div>
          )}

          {/* Favourites */}
          {favs.size > 0 && (
            <div className="mt-10">
              <h3 className="font-semibold mb-3">পছন্দের তালিকা</h3>
              <div className="flex flex-wrap gap-2">
                {[...favs].map(fid => {
                  const prod = RAW_PRODUCTS.find(p=>p.id===fid);
                  return (
                    <Badge key={fid} className="rounded-full" variant="secondary">
                      {prod?.title}
                      <button className="ml-2" onClick={()=> setFavs(prev=> { const ns = new Set(prev); ns.delete(fid); return ns; })}>
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  );
                })}
              </div>
            </div>
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t mt-8">
        <div className="max-w-7xl mx-auto px-4 py-8 text-sm text-muted-foreground flex flex-col md:flex-row items-center justify-between gap-4">
          <div>© {new Date().getFullYear()} ShopBangla — Demo E‑commerce</div>
          <div className="flex items-center gap-4">
            <a className="hover:underline" href="#">Privacy</a>
            <a className="hover:underline" href="#">Terms</a>
            <a className="hover:underline" href="#">Help</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
